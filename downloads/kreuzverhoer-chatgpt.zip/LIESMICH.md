# Kreuzverhör – für ChatGPT

Nimmt Entscheidungen mit echtem Zielkonflikt ins Kreuzverhör: Fünf Berater mit unterschiedlichen Denkweisen analysieren, eine anonyme Gegenprüfung und ein Faktencheck folgen, und der Vorsitz fällt ein klares Urteil mit offen ausgewiesenen Annahmen.

## Inhalt

- `kreuzverhoer/SKILL.md` – als ChatGPT-Skill (für Arbeitsbereiche, in denen Skills freigeschaltet sind)
- `custom-gpt-anweisungen.txt` – dieselbe Methode in Kurzform, zum Einfügen in die Anweisungen eines eigenen GPTs oder eines Projekts

## Variante 1: Als Skill

Wenn in deinem ChatGPT-Arbeitsbereich Skills verfügbar sind, den Ordner `kreuzverhoer` als Skill hochladen. Infos von OpenAI: [Skills in ChatGPT](https://academy.openai.com/public/resources/skills)

## Variante 2: Als eigenes GPT oder Projekt

Den Inhalt von `custom-gpt-anweisungen.txt` vollständig in das Feld für die Anweisungen eines eigenen GPTs oder eines Projekts kopieren. Websuche aktivieren, damit der Faktencheck funktioniert.

## Benutzung

- „Kreuzverhör: Soll ich Paket A oder B anbieten?“
- „Hier ist mein Businessplan, nimm ihn ins Kreuzverhör.“

Am besten mit einem Thinking- bzw. Reasoning-Modell und eingeschalteter Websuche.

## Unterschied zur Claude-Version

ChatGPT kann in dieser Form keine getrennten Sub-Agenten auf verschiedenen Modellen starten. Ein Modell spielt alle Rollen nacheinander. Die Unabhängigkeit der Berater ist deshalb geringer. Belegpflicht, Anonymisierung und Faktencheck gleichen das zum Teil aus.

## Hinweis

Die rechtlichen und steuerlichen Einschätzungen im Urteil sind allgemeine Informationen und ersetzen keine Fachberatung.

Methode nach Andrej Karpathys LLM Council. Die Grundidee fester Denkrollen geht auf den LLM-Council-Skill von Ole Lehmann zurück; Texte, Ablauf und Erweiterungen dieser Fassung sind eigenständig formuliert.
