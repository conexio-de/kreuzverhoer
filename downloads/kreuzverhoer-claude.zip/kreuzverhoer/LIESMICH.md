# Kreuzverhör – Skill für Claude

Nimmt Entscheidungen mit echtem Zielkonflikt ins Kreuzverhör: Fünf Berater mit unterschiedlichen Denkweisen analysieren unabhängig, prüfen sich gegenseitig anonym, ein Faktencheck prüft die tragenden Behauptungen, und der Vorsitz fällt ein klares Urteil mit offen ausgewiesenen Annahmen.

## Inhalt

- `SKILL.md` – der Skill
- `LIESMICH.md` – diese Datei

## Installation

Den Ordner `kreuzverhoer` als ZIP in Claude als eigenen Skill hinzufügen. Wie das in deiner Claude-Umgebung geht, beschreibt die Anthropic-Hilfe:

- [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude)
- [How to create custom skills](https://support.claude.com/en/articles/12512198-how-to-create-custom-skills)

## Benutzung

Im Chat zum Beispiel:

- „Kreuzverhör: Soll ich Paket A oder B anbieten?“
- „/kreuzverhör Hier ist mein Businessplan, trägt er?“
- „Nimm das auf den Prüfstand.“

Der Skill arbeitet mit Sub-Agenten auf verschiedenen Claude-Modellen (Opus, Sonnet, Haiku). Am besten funktioniert er dort, wo Claude Sub-Agenten starten kann. Ohne diese Möglichkeit spielt Claude die Rollen nacheinander durch.

## Hinweis

Die rechtlichen und steuerlichen Einschätzungen im Urteil sind allgemeine Informationen und ersetzen keine Fachberatung.

Methode nach Andrej Karpathys LLM Council. Die Grundidee fester Denkrollen geht auf den LLM-Council-Skill von Ole Lehmann zurück; Texte, Ablauf und Erweiterungen dieser Fassung sind eigenständig formuliert.
